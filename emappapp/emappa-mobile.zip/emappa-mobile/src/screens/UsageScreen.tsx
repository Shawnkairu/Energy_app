import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { colors, spacing, fontSize, borderRadius } from '../theme';
import { GlassCard } from '../components';

export function UsageScreen() {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
    >
      <GlassCard style={styles.card}>
        <Text style={styles.sectionTitle}>Daily usage (kWh)</Text>
        <View style={styles.placeholder}>
          <Text style={styles.placeholderText}>Line chart goes here</Text>
        </View>
      </GlassCard>

      <GlassCard style={styles.card}>
        <Text style={styles.sectionTitle}>Provider mix</Text>
        <View style={styles.placeholder}>
          <Text style={styles.placeholderText}>Stacked bar goes here</Text>
        </View>
      </GlassCard>

      <GlassCard style={styles.card}>
        <Text style={styles.sectionTitle}>Coming soon</Text>
        <Text style={styles.tipText}>
          Full usage charts will be available once we add a charting library.
          For now, view detailed usage in the Billing screen.
        </Text>
      </GlassCard>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
    paddingBottom: spacing.xxxl,
  },
  card: {
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: fontSize.lg,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.md,
  },
  placeholder: {
    height: 140,
    backgroundColor: colors.secondary + '59', // 35% opacity
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.soft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholderText: {
    color: colors.textMuted,
    fontSize: fontSize.md,
  },
  tipText: {
    color: colors.textMuted,
    fontSize: fontSize.md,
    lineHeight: 22,
  },
});
