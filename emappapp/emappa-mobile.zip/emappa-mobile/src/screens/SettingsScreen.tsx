import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  Switch,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { colors, spacing, fontSize, borderRadius } from '../theme';
import { GlassCard } from '../components';
import { allowanceService, appPrefs } from '../services';

export function SettingsScreen() {
  const [monthlyAllowance, setMonthlyAllowance] = useState('100');
  const [rollover, setRollover] = useState(true);
  const [deductionOrder, setDeductionOrder] = useState('allowance → tokens → postpaid');

  const loadData = useCallback(async () => {
    await allowanceService.ensureCurrentPeriod();
    setMonthlyAllowance(
      (allowanceService.state?.monthlyAllowanceKwh ?? 100).toFixed(0)
    );
    setRollover(allowanceService.state?.rollover ?? true);

    const order = await appPrefs.getDeductionOrder();
    setDeductionOrder(order.join(' → '));
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const handleSave = async () => {
    const value = parseFloat(monthlyAllowance);
    if (isNaN(value) || value <= 0) {
      Alert.alert('Invalid', 'Please enter a valid allowance');
      return;
    }

    await allowanceService.setPlan(value, rollover, true);
    Alert.alert('Saved', 'Settings updated successfully');
  };

  const handleRotateOrder = async () => {
    const next = await appPrefs.rotateDeductionOrder();
    setDeductionOrder(next.join(' → '));
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
    >
      <GlassCard style={styles.card}>
        <Text style={styles.sectionTitle}>Monthly Allowance (kWh)</Text>
        <TextInput
          style={styles.input}
          value={monthlyAllowance}
          onChangeText={setMonthlyAllowance}
          keyboardType="numeric"
          placeholder="e.g. 100"
          placeholderTextColor={colors.textMuted}
        />

        <View style={styles.switchRow}>
          <Text style={styles.switchLabel}>Rollover unused kWh</Text>
          <Switch
            value={rollover}
            onValueChange={setRollover}
            trackColor={{ false: colors.soft, true: colors.primary }}
            thumbColor={colors.surface}
          />
        </View>
      </GlassCard>

      <GlassCard style={styles.card}>
        <View style={styles.orderRow}>
          <View style={styles.orderInfo}>
            <Text style={styles.sectionTitle}>Deduction order</Text>
            <Text style={styles.orderText}>{deductionOrder}</Text>
          </View>
          <TouchableOpacity style={styles.rotateButton} onPress={handleRotateOrder}>
            <Text style={styles.rotateButtonText}>Rotate</Text>
          </TouchableOpacity>
        </View>
      </GlassCard>

      <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
        <Text style={styles.saveButtonText}>Save</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
    paddingBottom: spacing.xxxl,
  },
  card: {
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: fontSize.lg,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.md,
  },
  input: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.soft,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    fontSize: fontSize.lg,
    color: colors.text,
    marginBottom: spacing.lg,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  switchLabel: {
    fontSize: fontSize.md,
    color: colors.text,
  },
  orderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  orderInfo: {
    flex: 1,
  },
  orderText: {
    color: colors.textMuted,
    fontSize: fontSize.md,
  },
  rotateButton: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
  },
  rotateButtonText: {
    color: colors.primary,
    fontWeight: '600',
    fontSize: fontSize.md,
  },
  saveButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.lg,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  saveButtonText: {
    color: colors.surface,
    fontWeight: '700',
    fontSize: fontSize.lg,
  },
});
