// e.mappa brand palette (matching Flutter app)
export const colors = {
  // Primary palette
  primary: '#89B0AE',      // teal/green-gray
  secondary: '#BEE3DB',    // pale teal
  accent: '#FFD6BA',       // peach highlight
  background: '#FAF9F9',   // soft white
  surface: '#FFFFFF',      // card white

  // Text
  text: '#1A1A1A',         // near black
  textMuted: '#666666',    // gray
  textLight: '#999999',    // lighter gray

  // Support
  soft: '#E9E9E9',         // borders/dividers
  ink: '#555B6E',          // deep slate

  // Status
  success: '#4CAF50',
  warning: '#FF9800',
  error: '#F44336',
  online: '#26A69A',       // teal for "online" chip

  // Dark accents (for contrast elements)
  darkBg: '#0B0D10',
  darkCard: '#0F1419',
  darkBorder: '#1E2935',
} as const;

export type ColorName = keyof typeof colors;
